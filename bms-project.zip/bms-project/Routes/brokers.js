const express = require('express');
const routeBrokers = express.Router();
const brokers = require('../controllers/brokers');
routeBrokers.get('/brokers-data',brokers.brokersData);
routeBrokers.get('/brokers-graph',brokers.sendJSON);
module.exports = routeBrokers;