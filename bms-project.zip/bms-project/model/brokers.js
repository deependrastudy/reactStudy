exports.queryresp= async (query)=>{
   return await db.any(query);
}