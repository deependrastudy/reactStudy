const http = require('http');
const express = require('express');

const brokersRoute = require('./Routes/brokers');
const expressHbs = require('express-handlebars');
const app  = express();
const path = require('path');
var pgp = require('pg-promise')(/* options */)  
const cn = {
    host: 'localhost', // 'localhost' is the default;
    port: 5432, // 5432 is the default;
    database: 'dbname',
    user: 'root',
    password: '',
    allowExitOnIdle: true
};
global.db = pgp(cn); // database instance;

app.engine('hbs', expressHbs.engine({layoutsDir:'views/layouts',defaultLayout:'main-layout',extname:"hbs"}));
app.set("view engine","hbs");
app.set("views","views");
const bodyparser = require('body-parser');
app.use(bodyparser.urlencoded({"extended":"false"}));
///http://localhost:5000/admin/brokers-data//
app.use('/admin',brokersRoute)
app.use(express.static(path.join(__dirname,'public')));
app.use((req,res,next)=>{
   res.redirect("/admin/brokers-data");
})
app.listen(5000);