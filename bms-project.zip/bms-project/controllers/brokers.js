const modelObj = require("../model/brokers");
const getColor=()=>{
  var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
exports.brokersData = async (req,res,next)=>{ 
  let query1 = `select d.*,s.title from deals as d join sites as s on d.site_id = s.id order by listing_date DESC`;
  let query2 = `SELECT date_trunc('month', created_at) AS month , site_id ,count(site_id) as total , avg(revenue) as TotalRevenue FROM "deals_history" GROUP BY  date_trunc('month', created_at), site_id`;
  let data = await modelObj.queryresp(query1);
  let data2 = await modelObj.queryresp(query2);
  const month = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  let list = [];
  data.map((item)=>{
      let dateobj =  new Date(item.listing_date);
      item['month'] = month[dateobj.getUTCMonth()];
      item['date'] = dateobj.getUTCDate()+'-'+(dateobj.getUTCMonth()+1)+'-'+dateobj.getUTCFullYear();
      list.push(item);
  });
  let revenue_list = [];
  data2.map((item)=>{
    let dateobj =  new Date(item.month);
    item['month_name'] = month[dateobj.getUTCMonth()];
    item['date'] = dateobj.getUTCDate()+'-'+(dateobj.getUTCMonth()+1)+'-'+dateobj.getUTCFullYear();
    item['totalrevenue'] = parseFloat(item.totalrevenue).toFixed(2);
    revenue_list.push(item);
  })
  res.render('brokers',{pageTitle:"Brokers Data",revenue_list:revenue_list,list: data,listExists: true,layout:false});
}
exports.sendJSON = async  (req,res,next)=>{
  let query3 = `select * from sites`;
  let query1 = `SELECT date_trunc('month', created_at) AS month , site_id ,count(site_id) as total , avg(revenue) as TotalRevenue FROM "deals_history" GROUP BY  date_trunc('month', created_at), site_id`;
  let resp3 = await modelObj.queryresp(query3);
  let resp1 = await modelObj.queryresp(query1);
  let tree  = [];
  resp3.map((item)=>{
    let arr = [0,0,0,0,0,0,0,0,0,0,0,0,0];
    resp1.map((item2)=>{
            let dateobj = new Date(item2.month);
            let month = dateobj.getUTCMonth()+1;
            let year = dateobj.getUTCFullYear();
            if(month==11 && year==2020 && item.id===item2.site_id) 
              arr[0] = item2.total;
            else if(month==12 && year==2020 && item.id===item2.site_id)
              arr[1] = item2.total;
            else if(month==1 && year==2021 && item.id===item2.site_id)
              arr[2] = item2.total;
            else if(month==2 && year==2021 && item.id===item2.site_id)
              arr[3] = item2.total;
            else if(month==3 && year==2021 && item.id===item2.site_id)
              arr[4] = item2.total;
            else if(month==4 && year==2021 && item.id===item2.site_id)
              arr[5] = item2.total;
            else if(month==5 && year==2021 && item.id===item2.site_id)
              arr[6] = item2.total;
            else if(month==6 && year==2021 && item.id===item2.site_id)
              arr[7] = item2.total;
            else if(month==7 && year==2021 && item.id===item2.site_id)
              arr[8] = item2.total;
            else if(month==8 && year==2021 && item.id===item2.site_id)
              arr[9] = item2.total;
            else if(month==9 && year==2021 && item.id===item2.site_id)
              arr[10] = item2.total;
            else if(month==10 && year==2021 && item.id===item2.site_id) {
              arr[11] = item2.total;
            } 
    })
    tree.push({
      label: item.title,
      fill: true,
      lineTension: 0,
      borderColor: getColor(),
      data: arr,
      fill: false,
      borderColor: getColor(),
      tension: 0.1
  })
  })
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(tree)); 
}